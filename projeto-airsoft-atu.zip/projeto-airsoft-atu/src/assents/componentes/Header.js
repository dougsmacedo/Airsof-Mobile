import React from 'react';
import { StyleSheet, View, Text } from 'react-native';

const Header = ({ title, children }) => {
  return <Text style={styles.text}>Mov Airsoft</Text>}

const styles = StyleSheet.create({

});

export default Header;

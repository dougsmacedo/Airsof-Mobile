import React, { useState } from 'react';
import {View, StyleSheet} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import Main from '../Navigations/Main';

export default function ListaEventos({ navigation }) {

 return(

<View style={styles.container}>

</View>

);

}

const styles = StyleSheet.create(
  {
    container:{
      flex: 1,
      backgroundColor: '#f0870c'
    },

  })